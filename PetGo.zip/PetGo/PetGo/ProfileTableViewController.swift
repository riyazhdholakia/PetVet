//
//  ProfileTableViewController.swift
//  PetGo
//
//  Created by Riyazh Dholakia on 4/15/19.
//  Copyright © 2019 Riyazh Dholakia. All rights reserved.
//

import UIKit

class ProfileTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
//    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        
//    }
//    
//    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        
//    }
//    
//    override func numberOfSections(in tableView: UITableView) -> Int {
//        
//    }
//    
}
