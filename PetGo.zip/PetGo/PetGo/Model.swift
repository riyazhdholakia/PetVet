//
//  Model.swift
//  PetGo
//
//  Created by Riyazh Dholakia on 4/19/19.
//  Copyright © 2019 Riyazh Dholakia. All rights reserved.
//

import UIKit

struct Customer {
    var name: String?
    var uid: [String] = []
    
}
